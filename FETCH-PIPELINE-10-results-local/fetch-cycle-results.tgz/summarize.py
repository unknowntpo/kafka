import glob,re,sys,statistics as st,os
base=sys.argv[1]
for b in ("b1","b3"):
    nb=int(b[1])
    for key in ("control-default","branch-default","branch-mpfb256k","branch-mpfb4m"):
        rows=[]
        for f in sorted(glob.glob(f"{base}/{b}/{key}.rep*.out")):
            t=open(f).read().splitlines()
            c=t[1].split(",")
            m={}
            for l in t:
                g=re.match(r"consumer-fetch-manager-metrics:(fetch-latency-avg|fetch-total|fetch-size-avg):\{client-id=perf-consumer-client\}\s*:\s*([\d.]+)",l)
                if g:m[g.group(1)]=float(g.group(2))
            ft=float(c[7])/1000
            util=m["fetch-total"]*m["fetch-latency-avg"]/1000/nb/ft
            thr=open(f[:-4]+".threads").read()
            def cpu(n):
                g=re.search(r"\s(\d+\.\d)\s+\d+\.\d\s+\S+\s+"+n,thr); return g.group(1) if g else "-"
            rows.append((float(c[3]),float(c[8]),m["fetch-latency-avg"],m["fetch-size-avg"]/1e6,m["fetch-total"]/ft,util,cpu("main"),cpu("consumer_backgr"),open(f[:-4]+".stats").read().replace("\n"," ")[:60]))
        rows.sort()
        r=rows[len(rows)//2]
        print(b,key,"MB/s all",[round(x[0]) for x in rows],"| median: fetchMB/s %.0f lat %.1fms size %.1fMB fetch/s %.0f util/conn %.2f app %s net %s | %s"%r[1:])
